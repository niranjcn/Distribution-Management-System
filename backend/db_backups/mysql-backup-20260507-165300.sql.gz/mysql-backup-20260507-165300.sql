/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-11.8.6-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: mysql    Database: distribution_management_system
-- ------------------------------------------------------
-- Server version	8.4.9

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `api_activity_logs`
--

DROP TABLE IF EXISTS `api_activity_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `api_activity_logs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `actor_id` varchar(64) DEFAULT NULL,
  `actor_name` varchar(255) DEFAULT NULL,
  `actor_role` varchar(64) DEFAULT NULL,
  `method` varchar(16) NOT NULL,
  `path` varchar(255) NOT NULL,
  `status_code` int DEFAULT NULL,
  `description` longtext,
  `ip_address` varchar(64) DEFAULT NULL,
  `created_at` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_api_activity_logs_created_at` (`created_at`),
  KEY `idx_api_activity_logs_actor_name` (`actor_name`),
  KEY `idx_api_activity_logs_path` (`path`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `api_activity_logs`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `api_activity_logs` WRITE;
/*!40000 ALTER TABLE `api_activity_logs` DISABLE KEYS */;
INSERT INTO `api_activity_logs` VALUES
(1,'1','System Super Admin','super_admin','POST','/api/auth/login',200,'User logged in','172.19.0.1','2026-05-07T16:35:51.653421'),
(2,'1','System Super Admin','super_admin','POST','/api/auth/complete-forced-update',200,'Completed forced first-login credential rotation','172.19.0.1','2026-05-07T16:36:17.451685');
/*!40000 ALTER TABLE `api_activity_logs` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `approval_role_routing`
--

DROP TABLE IF EXISTS `approval_role_routing`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `approval_role_routing` (
  `id` int NOT NULL AUTO_INCREMENT,
  `approval_type` varchar(64) NOT NULL,
  `admin_enabled` tinyint(1) DEFAULT '1',
  `manager_enabled` tinyint(1) DEFAULT '1',
  `staff_enabled` tinyint(1) DEFAULT '1',
  `updated_by` varchar(64) DEFAULT NULL,
  `updated_at` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `approval_type` (`approval_type`),
  KEY `idx_approval_role_routing_type` (`approval_type`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `approval_role_routing`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `approval_role_routing` WRITE;
/*!40000 ALTER TABLE `approval_role_routing` DISABLE KEYS */;
INSERT INTO `approval_role_routing` VALUES
(1,'distribution',1,1,1,'system','2026-05-07 16:30:34'),
(2,'return',1,1,1,'system','2026-05-07 16:30:34'),
(3,'defect',1,1,1,'system','2026-05-07 16:30:34');
/*!40000 ALTER TABLE `approval_role_routing` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `approvals`
--

DROP TABLE IF EXISTS `approvals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `approvals` (
  `id` int NOT NULL AUTO_INCREMENT,
  `approval_type` varchar(64) NOT NULL,
  `entity_id` varchar(64) NOT NULL,
  `entity_type` varchar(64) NOT NULL,
  `requested_by` varchar(64) NOT NULL,
  `requested_by_name` varchar(255) DEFAULT NULL,
  `status` varchar(64) DEFAULT 'pending',
  `priority` varchar(32) DEFAULT 'medium',
  `request_date` varchar(64) NOT NULL,
  `approved_by` varchar(64) DEFAULT NULL,
  `approved_by_name` varchar(255) DEFAULT NULL,
  `approval_date` varchar(64) DEFAULT NULL,
  `rejection_reason` longtext,
  `notes` longtext,
  `created_at` varchar(64) NOT NULL,
  `updated_at` varchar(64) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `approvals`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `approvals` WRITE;
/*!40000 ALTER TABLE `approvals` DISABLE KEYS */;
/*!40000 ALTER TABLE `approvals` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `backup_schedules`
--

DROP TABLE IF EXISTS `backup_schedules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `backup_schedules` (
  `id` int NOT NULL,
  `frequency` varchar(16) NOT NULL,
  `day_of_week` int DEFAULT NULL,
  `day_of_month` int DEFAULT NULL,
  `time_of_day` varchar(5) NOT NULL,
  `last_run_at` varchar(64) DEFAULT NULL,
  `updated_at` varchar(64) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backup_schedules`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `backup_schedules` WRITE;
/*!40000 ALTER TABLE `backup_schedules` DISABLE KEYS */;
INSERT INTO `backup_schedules` VALUES
(1,'daily',NULL,NULL,'16:53',NULL,'2026-05-07T16:52:41');
/*!40000 ALTER TABLE `backup_schedules` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `change_requests`
--

DROP TABLE IF EXISTS `change_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `change_requests` (
  `id` int NOT NULL AUTO_INCREMENT,
  `request_id` varchar(128) NOT NULL,
  `requested_by` int NOT NULL,
  `requested_by_name` varchar(255) NOT NULL,
  `requested_by_role` varchar(64) NOT NULL,
  `request_type` varchar(128) NOT NULL,
  `new_email` varchar(255) DEFAULT NULL,
  `new_password` varchar(255) DEFAULT NULL,
  `device_id` varchar(64) DEFAULT NULL,
  `requested_status` varchar(64) DEFAULT NULL,
  `reason` longtext,
  `status` varchar(32) DEFAULT 'pending',
  `reviewed_by` int DEFAULT NULL,
  `reviewed_by_name` varchar(255) DEFAULT NULL,
  `review_note` longtext,
  `created_at` varchar(64) NOT NULL,
  `updated_at` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `request_id` (`request_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `change_requests`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `change_requests` WRITE;
/*!40000 ALTER TABLE `change_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `change_requests` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `defects`
--

DROP TABLE IF EXISTS `defects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `defects` (
  `id` int NOT NULL AUTO_INCREMENT,
  `report_id` varchar(128) NOT NULL,
  `device_id` varchar(64) NOT NULL,
  `device_serial` varchar(255) DEFAULT NULL,
  `device_type` varchar(128) DEFAULT NULL,
  `reported_by` varchar(64) NOT NULL,
  `reported_by_name` varchar(255) DEFAULT NULL,
  `defect_type` varchar(64) NOT NULL,
  `severity` varchar(64) NOT NULL,
  `description` longtext NOT NULL,
  `symptoms` longtext,
  `report_target` varchar(64) DEFAULT 'manager_admin',
  `forwarded_to_management` tinyint(1) DEFAULT '0',
  `forwarded_to_management_at` varchar(64) DEFAULT NULL,
  `forwarded_to_management_by` varchar(64) DEFAULT NULL,
  `forwarded_to_management_by_name` varchar(255) DEFAULT NULL,
  `operator_id` varchar(64) DEFAULT NULL,
  `sub_distributor_id` varchar(64) DEFAULT NULL,
  `status` varchar(64) DEFAULT 'reported',
  `resolution` longtext,
  `resolved_by` varchar(64) DEFAULT NULL,
  `resolved_by_name` varchar(255) DEFAULT NULL,
  `resolved_at` varchar(64) DEFAULT NULL,
  `replacement_requested_at` varchar(64) DEFAULT NULL,
  `replacement_confirmed_at` varchar(64) DEFAULT NULL,
  `replacement_confirmed_by` varchar(64) DEFAULT NULL,
  `replacement_confirmed_by_name` varchar(255) DEFAULT NULL,
  `return_amount` double DEFAULT '0',
  `service_charge` double DEFAULT '0',
  `payment_bill_url` varchar(255) DEFAULT NULL,
  `payment_confirmed` tinyint(1) DEFAULT '0',
  `payment_confirmed_at` varchar(64) DEFAULT NULL,
  `payment_confirmed_by` varchar(64) DEFAULT NULL,
  `payment_confirmed_by_name` varchar(255) DEFAULT NULL,
  `payment_due_user_id` varchar(64) DEFAULT NULL,
  `payment_due_user_name` varchar(255) DEFAULT NULL,
  `images` longtext,
  `created_at` varchar(64) NOT NULL,
  `updated_at` varchar(64) NOT NULL,
  `auto_return_id` varchar(64) DEFAULT NULL,
  `replacement_device_id` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `report_id` (`report_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `defects`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `defects` WRITE;
/*!40000 ALTER TABLE `defects` DISABLE KEYS */;
/*!40000 ALTER TABLE `defects` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `device_history`
--

DROP TABLE IF EXISTS `device_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `device_history` (
  `id` int NOT NULL AUTO_INCREMENT,
  `device_id` varchar(64) NOT NULL,
  `action` varchar(128) NOT NULL,
  `from_user_id` varchar(64) DEFAULT NULL,
  `from_user_name` varchar(255) DEFAULT NULL,
  `to_user_id` varchar(64) DEFAULT NULL,
  `to_user_name` varchar(255) DEFAULT NULL,
  `status_before` varchar(64) DEFAULT NULL,
  `status_after` varchar(64) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `notes` longtext,
  `performed_by` varchar(64) DEFAULT NULL,
  `performed_by_name` varchar(255) DEFAULT NULL,
  `timestamp` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_device_history_device_id` (`device_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `device_history`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `device_history` WRITE;
/*!40000 ALTER TABLE `device_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `device_history` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `devices`
--

DROP TABLE IF EXISTS `devices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `devices` (
  `id` int NOT NULL AUTO_INCREMENT,
  `device_id` varchar(128) NOT NULL,
  `device_type` varchar(128) NOT NULL,
  `model` varchar(255) NOT NULL,
  `serial_number` varchar(255) DEFAULT NULL,
  `mac_address` varchar(255) DEFAULT NULL,
  `manufacturer` varchar(255) NOT NULL,
  `band_type` varchar(64) DEFAULT NULL,
  `nuid` varchar(255) DEFAULT NULL,
  `status` varchar(64) DEFAULT 'available',
  `current_location` varchar(255) DEFAULT NULL,
  `current_holder_id` varchar(64) DEFAULT NULL,
  `current_holder_name` varchar(255) DEFAULT NULL,
  `registered_by_name` varchar(255) DEFAULT NULL,
  `current_holder_type` varchar(64) DEFAULT NULL,
  `purchase_date` varchar(64) DEFAULT NULL,
  `warranty_expiry` varchar(64) DEFAULT NULL,
  `metadata` longtext,
  `created_at` varchar(64) NOT NULL,
  `updated_at` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `device_id` (`device_id`),
  UNIQUE KEY `serial_number` (`serial_number`),
  UNIQUE KEY `mac_address` (`mac_address`),
  UNIQUE KEY `nuid` (`nuid`),
  UNIQUE KEY `uq_devices_nuid` (`nuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `devices`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `devices` WRITE;
/*!40000 ALTER TABLE `devices` DISABLE KEYS */;
/*!40000 ALTER TABLE `devices` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `distributions`
--

DROP TABLE IF EXISTS `distributions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `distributions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `distribution_id` varchar(128) NOT NULL,
  `device_ids` longtext NOT NULL,
  `device_count` int DEFAULT '0',
  `from_user_id` varchar(64) NOT NULL,
  `from_user_name` varchar(255) DEFAULT NULL,
  `from_user_type` varchar(64) DEFAULT NULL,
  `to_user_id` varchar(64) NOT NULL,
  `to_user_name` varchar(255) DEFAULT NULL,
  `to_user_type` varchar(64) DEFAULT NULL,
  `status` varchar(64) DEFAULT 'pending',
  `request_date` varchar(64) NOT NULL,
  `date_of_distribution` varchar(64) DEFAULT NULL,
  `approval_date` varchar(64) DEFAULT NULL,
  `delivery_date` varchar(64) DEFAULT NULL,
  `notes` longtext,
  `manifest_file` varchar(255) DEFAULT NULL,
  `approved_by` varchar(64) DEFAULT NULL,
  `approved_by_name` varchar(255) DEFAULT NULL,
  `created_by` varchar(64) NOT NULL,
  `created_at` varchar(64) NOT NULL,
  `updated_at` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `distribution_id` (`distribution_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `distributions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `distributions` WRITE;
/*!40000 ALTER TABLE `distributions` DISABLE KEYS */;
/*!40000 ALTER TABLE `distributions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `external_inventory_items`
--

DROP TABLE IF EXISTS `external_inventory_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `external_inventory_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `inventory_id` varchar(128) NOT NULL,
  `item_id` varchar(128) NOT NULL,
  `name` varchar(255) NOT NULL,
  `serial_number` varchar(255) DEFAULT NULL,
  `mac_id` varchar(255) DEFAULT NULL,
  `identifier_type` varchar(128) DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `device_type` varchar(128) NOT NULL,
  `price` double DEFAULT '0',
  `sku` varchar(128) DEFAULT NULL,
  `category` varchar(128) DEFAULT NULL,
  `unit` varchar(32) DEFAULT 'pcs',
  `quantity_on_hand` int DEFAULT '0',
  `reorder_level` int DEFAULT '0',
  `unit_cost` double DEFAULT '0',
  `supplier_name` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `status` varchar(32) DEFAULT 'active',
  `notes` longtext,
  `image_url` varchar(255) DEFAULT NULL,
  `created_by` varchar(64) DEFAULT NULL,
  `created_at` varchar(64) NOT NULL,
  `updated_at` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `inventory_id` (`inventory_id`),
  KEY `idx_external_inventory_items_item_id` (`item_id`),
  KEY `idx_external_inventory_items_serial_number` (`serial_number`),
  KEY `idx_external_inventory_items_mac_id` (`mac_id`),
  KEY `idx_external_inventory_items_device_type` (`device_type`),
  KEY `idx_external_inventory_items_status` (`status`),
  KEY `idx_external_inventory_items_sku` (`sku`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `external_inventory_items`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `external_inventory_items` WRITE;
/*!40000 ALTER TABLE `external_inventory_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `external_inventory_items` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `inventory_po_lines`
--

DROP TABLE IF EXISTS `inventory_po_lines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventory_po_lines` (
  `id` int NOT NULL AUTO_INCREMENT,
  `po_id` varchar(128) NOT NULL,
  `item_inventory_id` varchar(128) NOT NULL,
  `item_sku` varchar(128) DEFAULT NULL,
  `item_name` varchar(255) DEFAULT NULL,
  `quantity_ordered` int NOT NULL,
  `unit_cost` double DEFAULT '0',
  `line_total` double DEFAULT '0',
  `created_at` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_inventory_po_lines_po_id` (`po_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_po_lines`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `inventory_po_lines` WRITE;
/*!40000 ALTER TABLE `inventory_po_lines` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventory_po_lines` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `inventory_purchase_orders`
--

DROP TABLE IF EXISTS `inventory_purchase_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventory_purchase_orders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `po_id` varchar(128) NOT NULL,
  `supplier_name` varchar(255) NOT NULL,
  `status` varchar(32) DEFAULT 'draft',
  `expected_date` varchar(64) DEFAULT NULL,
  `ordered_by` varchar(64) NOT NULL,
  `ordered_by_name` varchar(255) DEFAULT NULL,
  `total_amount` double DEFAULT '0',
  `notes` longtext,
  `created_at` varchar(64) NOT NULL,
  `updated_at` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `po_id` (`po_id`),
  KEY `idx_inventory_purchase_orders_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_purchase_orders`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `inventory_purchase_orders` WRITE;
/*!40000 ALTER TABLE `inventory_purchase_orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventory_purchase_orders` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `inventory_receipt_lines`
--

DROP TABLE IF EXISTS `inventory_receipt_lines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventory_receipt_lines` (
  `id` int NOT NULL AUTO_INCREMENT,
  `receipt_id` varchar(128) NOT NULL,
  `item_inventory_id` varchar(128) NOT NULL,
  `item_sku` varchar(128) DEFAULT NULL,
  `item_name` varchar(255) DEFAULT NULL,
  `quantity_received` int NOT NULL,
  `unit_cost` double DEFAULT '0',
  `line_total` double DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_inventory_receipt_lines_receipt_id` (`receipt_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_receipt_lines`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `inventory_receipt_lines` WRITE;
/*!40000 ALTER TABLE `inventory_receipt_lines` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventory_receipt_lines` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `inventory_receipts`
--

DROP TABLE IF EXISTS `inventory_receipts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventory_receipts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `receipt_id` varchar(128) NOT NULL,
  `po_id` varchar(128) NOT NULL,
  `supplier_name` varchar(255) DEFAULT NULL,
  `received_by` varchar(64) NOT NULL,
  `received_by_name` varchar(255) DEFAULT NULL,
  `notes` longtext,
  `created_at` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `receipt_id` (`receipt_id`),
  KEY `idx_inventory_receipts_po_id` (`po_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_receipts`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `inventory_receipts` WRITE;
/*!40000 ALTER TABLE `inventory_receipts` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventory_receipts` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `inventory_stock_movements`
--

DROP TABLE IF EXISTS `inventory_stock_movements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventory_stock_movements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `movement_id` varchar(128) NOT NULL,
  `item_inventory_id` varchar(128) NOT NULL,
  `item_sku` varchar(128) DEFAULT NULL,
  `item_name` varchar(255) DEFAULT NULL,
  `movement_type` varchar(64) NOT NULL,
  `quantity` int NOT NULL,
  `reference_type` varchar(64) DEFAULT NULL,
  `reference_id` varchar(128) DEFAULT NULL,
  `notes` longtext,
  `performed_by` varchar(64) DEFAULT NULL,
  `performed_by_name` varchar(255) DEFAULT NULL,
  `created_at` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `movement_id` (`movement_id`),
  KEY `idx_inventory_stock_movements_item_id` (`item_inventory_id`),
  KEY `idx_inventory_stock_movements_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_stock_movements`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `inventory_stock_movements` WRITE;
/*!40000 ALTER TABLE `inventory_stock_movements` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventory_stock_movements` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` varchar(64) NOT NULL,
  `title` varchar(255) NOT NULL,
  `message` longtext NOT NULL,
  `type` varchar(64) DEFAULT 'info',
  `category` varchar(64) NOT NULL,
  `is_read` tinyint(1) DEFAULT '0',
  `link` varchar(255) DEFAULT NULL,
  `metadata` longtext,
  `created_at` varchar(64) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `operators`
--

DROP TABLE IF EXISTS `operators`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `operators` (
  `id` int NOT NULL AUTO_INCREMENT,
  `operator_id` varchar(128) NOT NULL,
  `name` varchar(255) NOT NULL,
  `phone` varchar(64) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `area` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `assigned_to` varchar(64) NOT NULL,
  `assigned_to_name` varchar(255) DEFAULT NULL,
  `status` varchar(32) DEFAULT 'active',
  `device_count` int DEFAULT '0',
  `connection_type` varchar(64) DEFAULT NULL,
  `created_at` varchar(64) NOT NULL,
  `updated_at` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `operator_id` (`operator_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `operators`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `operators` WRITE;
/*!40000 ALTER TABLE `operators` DISABLE KEYS */;
/*!40000 ALTER TABLE `operators` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `returns`
--

DROP TABLE IF EXISTS `returns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `returns` (
  `id` int NOT NULL AUTO_INCREMENT,
  `return_id` varchar(128) NOT NULL,
  `device_id` varchar(64) NOT NULL,
  `device_serial` varchar(255) DEFAULT NULL,
  `device_type` varchar(128) DEFAULT NULL,
  `requested_by` varchar(64) NOT NULL,
  `requested_by_name` varchar(255) DEFAULT NULL,
  `return_to` varchar(64) DEFAULT NULL,
  `return_to_name` varchar(255) DEFAULT NULL,
  `reason` varchar(64) NOT NULL,
  `description` longtext,
  `status` varchar(64) DEFAULT 'pending',
  `request_date` varchar(64) NOT NULL,
  `approval_date` varchar(64) DEFAULT NULL,
  `received_date` varchar(64) DEFAULT NULL,
  `approved_by` varchar(64) DEFAULT NULL,
  `approved_by_name` varchar(255) DEFAULT NULL,
  `defect_id` varchar(64) DEFAULT NULL,
  `mac_address` varchar(255) DEFAULT NULL,
  `created_at` varchar(64) NOT NULL,
  `updated_at` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `return_id` (`return_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `returns`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `returns` WRITE;
/*!40000 ALTER TABLE `returns` DISABLE KEYS */;
/*!40000 ALTER TABLE `returns` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `token_blacklist`
--

DROP TABLE IF EXISTS `token_blacklist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `token_blacklist` (
  `token_hash` varchar(255) NOT NULL,
  `expires_at` varchar(64) NOT NULL,
  `created_at` varchar(64) NOT NULL,
  PRIMARY KEY (`token_hash`),
  KEY `idx_token_blacklist_expires_at` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `token_blacklist`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `token_blacklist` WRITE;
/*!40000 ALTER TABLE `token_blacklist` DISABLE KEYS */;
/*!40000 ALTER TABLE `token_blacklist` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `password_hash` text NOT NULL,
  `role` varchar(64) NOT NULL,
  `digital_id` varchar(128) DEFAULT NULL,
  `broadband_id` varchar(128) DEFAULT NULL,
  `force_email_change` tinyint(1) DEFAULT '0',
  `force_password_change` tinyint(1) DEFAULT '0',
  `phone` varchar(64) DEFAULT NULL,
  `department` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `status` varchar(32) DEFAULT 'active',
  `parent_id` int DEFAULT NULL,
  `permissions` longtext,
  `theme` varchar(32) DEFAULT 'light',
  `compact_mode` tinyint(1) DEFAULT '0',
  `email_notifications` tinyint(1) DEFAULT '1',
  `push_notifications` tinyint(1) DEFAULT '1',
  `is_verified` tinyint(1) DEFAULT '0',
  `created_at` varchar(64) NOT NULL,
  `updated_at` varchar(64) NOT NULL,
  `last_login` varchar(64) DEFAULT NULL,
  `failed_login_attempts` int DEFAULT '0',
  `locked_until` varchar(64) DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `idx_users_parent_id` (`parent_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,'superadmin@dms.com','System Super Admin','$2b$12$18UzVfdlGCcqL5UHSWP/KODMz6GXGLJ3G0K.8i0Z7ugqVblbzRzbG','super_admin',NULL,NULL,0,0,'+8801700000001','IT','Head Office','active',NULL,'{}','light',0,1,1,1,'2026-05-07T16:30:34.210499','2026-05-07T16:36:17.000819','2026-05-07T16:35:51.637839',0,NULL,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2026-05-07 16:53:00
